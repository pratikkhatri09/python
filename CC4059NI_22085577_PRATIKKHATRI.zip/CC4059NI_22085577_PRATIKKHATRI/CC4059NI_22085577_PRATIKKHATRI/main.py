#main file
from operation import *     
from read import *          #importing from different files
from write import*         

print("\n")
print("\n")
print("\t \t \t \t \t \t\t Pratik Rentals")
print("\t\t\t\t\t--------------------------------------------")
print("\t \t \t \t \t |Swoyambhu, kathmandu | Phone No:9841270569 ")
print("-----------------------------------------------------------------------------------------------------------------------------")
print("\t \t \t \t Welcome to the Pratik rentals! I hope you have a good day ahead!")
print("-----------------------------------------------------------------------------------------------------------------------------")
print("Below there are three options,  please choose any one to continue.")
print("-----------------------------------------------------------------------------------------------------------------------------")
print("Press 1 to rent items")
print("Press 2 to return")
print("Press 3 to exit the store")
print("-----------------------------------------------------------------------------------------------------------------------------")
print("\n")

loop=True
while (loop==True):    

    Input_user= (input("Please enter the option you want to continue: "))          #takes the input from the user to continue
    if Input_user=="1":

        name, contact_Number, items_purchased, date_time, grand_Total = function_for_rent()   
        bill_for_renting(name, contact_Number, items_purchased,date_time, grand_Total)        
        print("\n")
        print("\t\t\t\t\t\tThank you for renting!! ;)")

    elif Input_user=="2":
        name, contact_Number,items_purchased, date_time,grand_Total,fine,total_fine=function_for_returning()   
        bill_for_returning(name, contact_Number,items_purchased, date_time,grand_Total,fine,total_fine)
        print("\n")
        print("\t\t\t\t\t\tThank you for returning, hope you liked the items")

    elif Input_user=="3":    #ends the loop
        print("\t\t\t\t\t\tThank you for visiting our store! hope to see you soon!")
        loop=False      

    else:
        print("Invaid option, Please select a valid option!!")
                
    
    
